This is a pretty fun map - https://www.washingtonpost.com/graphics/national/power-plants/ - and it looks nice and complicated, so let's recreate it in a few different ways!

## HINTS

* One file is a delimited text layer, one is a shapefile/vector layer
* When importing the CSV, your CRS should usually be WGS 84
* To zoom in on an area, click the zoom button and drag an area
* Color etc is inside of "single marker" or "simple fill," but opacity (see-through-ness) is above that, under "Marker" or "Fill"
* We made different color graduated maps in class, but you can change the size instead of the color by selecting 'Method: Size' instead of 'Method: Color'
* When building a filter, "Test" works like "Apply" normally does
* If you don't know what the possible values of a field are (for example, the primary source of energy), you can always open up the CSV in your text editor to check
* You can find 'Points in Polygon' in the menu Vector > Analysis Tools > Count Points in Polygons
* When counting plants, `NUMPOINTS` seems fine, but if you're only counting certain kinds of power plants, maybe you should give it a more specific name.

## FILES

* [powerplants.csv](https://gist.github.com/jsoma/0865246bd9223a6b86fe6876efb4c640/raw/1db5a66d65b12e33042e090f52f6c4f7565bf329/powerplants.csv) - CSV of powerplants (Use right-click, save as...)
* [cb_2016_us_state_20m.zip](https://gist.github.com/jsoma/0865246bd9223a6b86fe6876efb4c640/raw/1db5a66d65b12e33042e090f52f6c4f7565bf329/cb_2016_us_state_20m.zip) - shapefile of US states

## PROJECT

I've given you a csv file of the power plants in the USA, and a shapefile of the states in the USA. Import both into QGIS.

![](https://gist.github.com/jsoma/0865246bd9223a6b86fe6876efb4c640/raw/1db5a66d65b12e33042e090f52f6c4f7565bf329/imported.png)

Zoom in on the **continental United States**.

![](https://gist.github.com/jsoma/0865246bd9223a6b86fe6876efb4c640/raw/1db5a66d65b12e33042e090f52f6c4f7565bf329/zoomed.png)

This is an ugly-looking USA! The process of converting from a 3D globe to a 2D page is called **projecting**. We can change the way it's displaying the US by changing the projection (we'll talk more about those at some point).

To make it look like the "real" USA, click the box in the lower right-hand corner next to **Render**. Search for `5070`

![](https://gist.github.com/jsoma/0865246bd9223a6b86fe6876efb4c640/raw/1db5a66d65b12e33042e090f52f6c4f7565bf329/projection.png)

Select it and your map will look much nicer!

![](https://gist.github.com/jsoma/0865246bd9223a6b86fe6876efb4c640/raw/1db5a66d65b12e33042e090f52f6c4f7565bf329/reprojected.png)

Every country has its own "best" projection - there isn't even a general idea of the right type, as it varies based on location and whether the countries runs north/south, east/west, or is square/round.

## Map 1: Dot map

Change the styles of both layers to make a simple dot map.

![](https://gist.github.com/jsoma/0865246bd9223a6b86fe6876efb4c640/raw/1db5a66d65b12e33042e090f52f6c4f7565bf329/dot-map.png)

## Map 2: Bubble map

Restyle the map to make a bubble map of total output of the powerplant (Total_MW)

![](https://gist.github.com/jsoma/0865246bd9223a6b86fe6876efb4c640/raw/1db5a66d65b12e33042e090f52f6c4f7565bf329/bubble-map.png)

## Map 3: Colored dot map

Restyle the map to make a colored dot map of source of the power plant's energy (PrimSource)

![](https://gist.github.com/jsoma/0865246bd9223a6b86fe6876efb4c640/raw/1db5a66d65b12e33042e090f52f6c4f7565bf329/colored-dot-map.png)

## Map 4: Colored bubble map

Restyle the map AGAIN to make a colored bubble map. This one is a PAIN.

First you'll make the colored dot map as usual, then go into **Change...** for the symbol. Click the box to the far right of **Size**, and pick the **Assistant** option.

![](https://gist.github.com/jsoma/0865246bd9223a6b86fe6876efb4c640/raw/1db5a66d65b12e33042e090f52f6c4f7565bf329/size-assistant-selector.png)

Pick `Total_MW` as your source, and click the refresh button to get the range for the field.

![](https://gist.github.com/jsoma/0865246bd9223a6b86fe6876efb4c640/raw/1db5a66d65b12e33042e090f52f6c4f7565bf329/size-assistant.png)

Play around with options in the bottom section until you get a map you like. It should auto-update.

![](https://gist.github.com/jsoma/0865246bd9223a6b86fe6876efb4c640/raw/1db5a66d65b12e33042e090f52f6c4f7565bf329/colored-bubble.png)

## Map 5: Coal only

You can also filter what you see on the map by right-clicking and picking **Filter** from the dropown.

![](https://gist.github.com/jsoma/0865246bd9223a6b86fe6876efb4c640/raw/1db5a66d65b12e33042e090f52f6c4f7565bf329/filter.png)

In this example, I'm filtering to only show the state of Virginia. Pay attention to the equals signs and the double vs. single quotation marks, they're important in QGIS!

![](https://gist.github.com/jsoma/0865246bd9223a6b86fe6876efb4c640/raw/1db5a66d65b12e33042e090f52f6c4f7565bf329/virginia-filter.png)

Make a map of **only coal-powered plants.**

![](https://gist.github.com/jsoma/0865246bd9223a6b86fe6876efb4c640/raw/1db5a66d65b12e33042e090f52f6c4f7565bf329/coal-bubble.png)

## Map 6: Solar only

Make a map of **only solar plants.**

![](https://gist.github.com/jsoma/0865246bd9223a6b86fe6876efb4c640/raw/1db5a66d65b12e33042e090f52f6c4f7565bf329/solar-bubble.png)

## Map 7: Solar choropleth

Count the number of solar plants in each state (counting points pays attention to filters!). Make a choropleth.

Give it a worthwhile column name, please.

![](https://gist.github.com/jsoma/0865246bd9223a6b86fe6876efb4c640/raw/1db5a66d65b12e33042e090f52f6c4f7565bf329/solar-choro.png)

## Map 8: Coal choropleth

Count the number of coal plants in each state. Make a choropleth.

Pay attention to the polygon you're using - you want it to be the one that also has the solar column in it!

![](https://gist.github.com/jsoma/0865246bd9223a6b86fe6876efb4c640/raw/1db5a66d65b12e33042e090f52f6c4f7565bf329/coal-choro.png)

## Map 9: Power output by state

Sigh, QGIS 3 really hid everything! First, turn on the **Processing Toolbox.**

![](https://gist.github.com/jsoma/0865246bd9223a6b86fe6876efb4c640/raw/1db5a66d65b12e33042e090f52f6c4f7565bf329/turn-on-toolbox.png)

Then search for "Join attributes by location"

![](https://gist.github.com/jsoma/0865246bd9223a6b86fe6876efb4c640/raw/1db5a66d65b12e33042e090f52f6c4f7565bf329/join-by-location-search.png)

We're going to pick **Join attributes by location (summary)**. You'll want to pick a few columns of interest, and make sure you're getting the **sum** of them (to total them up).

MAKE SURE YOU REMOVED YOUR FILTERS FROM THE PREVIOUS STEPS.

![](https://gist.github.com/jsoma/0865246bd9223a6b86fe6876efb4c640/raw/1db5a66d65b12e33042e090f52f6c4f7565bf329/location-join-options.png)

Run it, and now you should have a new shapefile with **extra columns in it!**

![](https://gist.github.com/jsoma/0865246bd9223a6b86fe6876efb4c640/raw/1db5a66d65b12e33042e090f52f6c4f7565bf329/spatial-joined-attribute-table.png)

Now build a map of the total megawatt output of each state, with powerplants overlaid on top of it.

![](https://gist.github.com/jsoma/0865246bd9223a6b86fe6876efb4c640/raw/1db5a66d65b12e33042e090f52f6c4f7565bf329/total-mw-with-plants.png)
